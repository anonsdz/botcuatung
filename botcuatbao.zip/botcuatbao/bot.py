import asyncio
import time
import subprocess  # Thêm dòng này để sử dụng subprocess
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from collections import defaultdict

# Nhập token bot của bạn vào đây
BOT_TOKEN = "7234477038:AAGn7GAQSvAU7x_A-VpnFlJ-NDMcSMBhe2g"

# Giới hạn cho người dùng thường
SPAM_LIMIT_NORMAL = 5
COMMAND_LIMIT_NORMAL = 5
API_LIMIT_FREE = 2
TIME_LIMIT = 30 * 60  # 15 phút

# Giới hạn cho người dùng VIP
SPAM_LIMIT_VIP = 50
COMMAND_LIMIT_VIP = 50
API_LIMIT_VIP = 10

# Danh sách tên người dùng VIP
VIP_USERS = {"javascriptflooder" ,"NeganSSHConsole"}  # Thay thế bằng tên người dùng VIP thực tế

# Bộ đếm lưu số lần gọi lệnh của mỗi người dùng trong khoảng thời gian nhất định
user_command_count = defaultdict(list)

# Biến để kiểm tra trạng thái của cuộc spam
spam_in_progress = defaultdict(bool)
spam_tasks = {}  # Quản lý các asyncio.Task để dừng nếu cần

# Hàm kiểm tra người dùng có phải VIP không
def is_vip(username):
    return username in VIP_USERS

# Hàm xử lý lệnh /aboutme
async def about_me_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or "Không rõ"
    username = username.lstrip('@') if username else username

    if is_vip(username):
        status = "VIP"
        command_limit = COMMAND_LIMIT_VIP
        api_speed = f"{API_LIMIT_VIP}x"
    else:
        status = "Free"
        command_limit = COMMAND_LIMIT_NORMAL
        api_speed = f"{API_LIMIT_FREE}x"

    current_time = time.time()
    recent_commands = [
        timestamp for timestamp in user_command_count[user_id] if current_time - timestamp < TIME_LIMIT
    ]
    user_command_count[user_id] = recent_commands
    slots_used = len(user_command_count[user_id])

    await update.message.reply_text(
        f"👤 Thông tin của bạn:\n"
        f"📌 ID người dùng: {user_id}\n"
        f"📌 Tên người dùng: @{username}\n"
        f"📌 Quyền: {status}\n"
        f"📌 Số lần được phép sử dụng: {command_limit} lần\n"
        f"📌 Số lượt đã sử dụng: {slots_used} lượt / {command_limit} lượt\n" )

# Hàm xử lý lệnh /spam
async def spam_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or "Không rõ"
    username = username.lstrip('@') if username else username
    current_time = time.time()

    if is_vip(username):
        spam_limit = SPAM_LIMIT_VIP
        command_limit = COMMAND_LIMIT_VIP
        api_speed = f"{API_LIMIT_VIP}x"
        status = "VIP"
    else:
        spam_limit = SPAM_LIMIT_NORMAL
        command_limit = COMMAND_LIMIT_NORMAL
        api_speed = f"{API_LIMIT_FREE}x"
        status = "Free"

    user_command_count[user_id] = [
        timestamp for timestamp in user_command_count[user_id] if current_time - timestamp < TIME_LIMIT
    ]

    if len(user_command_count[user_id]) >= command_limit:
        await update.message.reply_text(
            f"❗ Bạn đã sử dụng lệnh quá {command_limit} lần trong 30 phút. Vui lòng thử lại sau." )
        return

    if spam_in_progress[user_id]:
        await update.message.reply_text(
            "❗ Cuộc spam đang trong tiến trình, vui lòng đợi cho đến khi hoàn tất hoặc nhập /stop để dừng cuộc spam.")
        return

    try:
        if len(context.args) != 2:
            await update.message.reply_text("❗ Sử dụng: /spam <số_điện_thoại> <số_lần>")
            return

        phone_number = context.args[0]
        spam_count = context.args[1]

        if len(phone_number) != 10 or not phone_number.startswith("0"):
            await update.message.reply_text("❌ Lỗi: Số điện thoại không hợp lệ.")
            return

        if not spam_count.isdigit():
            await update.message.reply_text("❌ Lỗi: Số lần không hợp lệ.")
            return

        spam_count = int(spam_count)
        if spam_count > spam_limit:
            await update.message.reply_text(
                f"❗ Số lần giới hạn cho quyền {status} là {spam_limit}. Liên hệ Admin để nâng cấp thêm nhé." )
            return

        user_command_count[user_id].append(current_time)

        slot_info = f"{len(user_command_count[user_id])} / {spam_limit}"

        await update.message.reply_text(
            f"📌 Chi tiết spam:\n"
            f"🚀 Gửi bởi: @{username}\n"
            f"🚀 Số điện thoại: {phone_number}\n"
            f"🚀 Số lần: {spam_count} / {spam_limit}\n"
            f"🚀 Lượt: {slot_info}\n"
            f"🚀 Quyền: {status}\n"
            f"🎯 API sử dụng: {api_speed}\n"
            f"⚙️ Trạng thái: Đang spam..."
        )

        spam_in_progress[user_id] = True

        async def run_spam():
            try:
                # Thực thi lệnh sms.py
                result = await asyncio.to_thread(subprocess.run, ["python", "sms.py", phone_number, str(spam_count)], capture_output=True, text=True)
                await update.message.reply_text(f"Đã spam xong @{username}.")

            finally:
                spam_in_progress[user_id] = False

        spam_task = asyncio.create_task(run_spam())
        spam_tasks[user_id] = spam_task

    except Exception as e:
        await update.message.reply_text(f"❌ Đã xảy ra lỗi: {e}")

# Hàm xử lý lệnh /stop
async def stop_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not spam_in_progress.get(user_id, False):
        await update.message.reply_text("❗ Không có cuộc spam nào đang trong tiến trình.")
        return

    spam_task = spam_tasks.get(user_id)
    if spam_task:
        spam_task.cancel()
        spam_tasks.pop(user_id, None)
        await update.message.reply_text(f"Đã dừng cuộc spam thành công @{update.effective_user.username}.")
    else:
        await update.message.reply_text("❌Không tìm thấy tiến trình spam để dừng.")

# Hàm xử lý lệnh /add để thêm người dùng vào danh sách VIP
async def add_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.username != "javascriptflooder":

        await update.message.reply_text("❌ Chỉ Admin mới có thể sử dụng lệnh này.")
        return

    if len(context.args) != 1:
        await update.message.reply_text("❗ Sử dụng: /add <tên_người_dùng>")
        return

    username_to_add = context.args[0]
    VIP_USERS.add(username_to_add)
    await update.message.reply_text(f"Đã thêm @{username_to_add} vào danh sách VIP.")

# Hàm xử lý lệnh /remove để loại bỏ người dùng khỏi danh sách VIP
async def remove_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.username != "javascriptflooder":

        await update.message.reply_text("❌ Chỉ Admin mới có thể sử dụng lệnh này.")
        return

    if len(context.args) != 1:
        await update.message.reply_text("❗ Sử dụng: /remove <tên_người_dùng>")
        return

    username_to_remove = context.args[0]
    VIP_USERS.discard(username_to_remove)
    await update.message.reply_text(f"❗ Đã xóa @{username_to_remove} khỏi danh sách VIP.")

# Hàm hiển thị thông tin Admin
async def about_admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    admin_info = """
      👤 Thông tin Admin:
    - 🎯 Tên người dùng: @javascriptflooder
    - 🎯 Facebook: https://www.facebook.com/profile.php?id=61565759912042
    - 🎯 Email: dthanhbao8228@gmail.com
    - 🎯 Trạng thái: Đang hoạt động 🟢
    - 🛠 Quyền: Toàn quyền (Admin-Owner Bot) """
    await update.message.reply_text(admin_info)

# Hàm xử lý lệnh /start để giới thiệu và hiển thị các lệnh
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    welcome_text = f"""
    🤖 **Chào mừng đến với Bot spam SMS!**
    ⚡ **Bot này được vận hành bởi @javascriptflooder**    
    📜 **Danh sách lệnh bạn có thể sử dụng:**
    - `/start` - Hiển thị danh sách lệnh và giới thiệu.
    - `/rules` - Xem luật sử dụng bot.
    - `/aboutme` - Xem thông tin tài khoản của bạn.
    - `/aboutadmin` - Xem thông tin Admin.
    - `/spam` - Spam số điện thoại.
    - `/stop` - Dừng cuộc spam đang thực hiện.
    - `/buyvip` - Mua gói plan VIP spam.
    - `/events` - Xem các sự kiện về bot.
    - `/add` - Thêm người dùng vào VIP (Admin).
    - `/remove` - Xóa người dùng khỏi VIP (Admin).
    🌟 **Hãy sử dụng bot một cách có trách nhiệm nhé!**"""
    await update.message.reply_text(welcome_text, parse_mode="Markdown")   

# Hàm xử lý lệnh /rules để hiển thị luật sử dụng bot
async def rules_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rules_text = """
    📜 Luật sử dụng bot:
1️⃣ Người dùng Free:
    - Số lần gửi tin nhắn tối đa: 5 lần trong 30 phút.
    - Số lượt tối đa: 5 lần trong 30 phút.
    - Số API tối đa: 2x
2️⃣ Người dùng VIP:
    - Số lần gửi tin nhắn tối đa: 50 lần trong 30 phút.
    - Số lượt tối đa: 50 lần trong 30 phút.
    - Số API tối đa: 10x
3️⃣ Không được spam quá giới hạn quy định.
4️⃣ Không được spam các số của cơ quan công an, chính phủ hoặc các cơ quan chính trị.
5️⃣ Liên hệ Admin nếu muốn nâng cấp quyền hoặc bot gặp lỗi.
📌 Các members cần nghiêm túc tuân thủ các luật lệ của bot.
⚠️  Vi phạm luật nếu bị phát hiện sẽ bị hạn chế hoặc cấm truy cập bot 1 tuần. """
    await update.message.reply_text(rules_text)    

# Hàm xử lý lệnh /buyvip để hiển thị thông tin thanh toán
async def buy_vip_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    buy_vip_text = """
    💳 **Thông tin thanh toán :**
    📌 **Chi tiết giao dịch**
    - **Ngân hàng**: Vietcombank
    - **Số tài khoản**: 0501000149265
    - **Chủ tài khoản**: Nguyễn Thị Liễu
    - **Nội dung chuyển khoản: Mua plan VIP
    📌 **Thông tin về các gói plan có sẵn**:
    💎 - 15k/tuần (Plan-VIP)
    💎 - 30k/tháng (Plan-VIP)
    💎 - ???k/tháng (Plan-Super-VIP) sắp được ra mắt...
    📌 **Lưu ý**:
    1️⃣ Sau khi thanh toán, vui lòng gửi bill cho Admin để được nâng cấp.
    2️⃣ Thời gian trả lời tin nhắn: trong vòng 24 giờ.
    🎉 **Cảm ơn các bạn đã ủng hộ dịch vụ của mình nhé!**
    💬 **Nếu có bất kỳ thắc mắc nào, vui lòng liên hệ Admin: @javascriptflooder**
    🍀 **Chúc các bạn có 1 ngày mới thật tuyệt vời và vui vẻ nhé!**  """
    await update.message.reply_text(buy_vip_text, parse_mode="Markdown")     

# Thêm lệnh /events hiển thị các sự kiện của bot
async def events_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Danh sách các sự kiện tĩnh (hoặc có thể cập nhật động)
    events = [
        "🎉 01/1/2025: Update bot bản 1.2 với nhiều tính năng mới.",
        "⚙️ 03/1/2025: Bảo trì hệ thống từ 12:00 - 6:00 (GMT+7).",
        "📌 05/1/2025: Thêm tính năng mới: Tự động phản hồi AI.",
        "💪 06/1/2025: Ra mắt plan mới: Super-VIP.",
        "🎁 07/1/2025: Sự kiện Giveaway quà tặng plan VIP.",
        "🔔 10/1/2025: Thông báo cập nhật các API mới.", ]

    # Chuỗi hiển thị các sự kiện
    events_text = "\n".join(events)
    # Gửi phản hồi về danh sách sự kiện
    await update.message.reply_text(
        f"📅 **Các sự kiện sắp tới của bot:**\n{events_text}",
        parse_mode="Markdown" )
# Hàm khởi tạo bot
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # Thêm các handler cho lệnh
    app.add_handler(CommandHandler("spam", spam_command))
    app.add_handler(CommandHandler("stop", stop_command))
    app.add_handler(CommandHandler("aboutme", about_me_command))  # Thêm lệnh /aboutme
    app.add_handler(CommandHandler("aboutadmin", about_admin_command))  # Thêm lệnh /aboutadmin
    app.add_handler(CommandHandler("add", add_vip))  # Lệnh /add
    app.add_handler(CommandHandler("remove", remove_vip))  # Lệnh /remove
    app.add_handler(CommandHandler("rules", rules_command))  # Thêm lệnh /rules
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("buyvip", buy_vip_command))
    app.add_handler(CommandHandler("events", events_command))  # Lệnh /events
    app.run_polling()

if __name__ == "__main__":
    main()
